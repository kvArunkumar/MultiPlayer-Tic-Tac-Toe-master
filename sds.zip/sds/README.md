## Multi Player Tic Toe

This project is a multi player version of [Tic Tac Toe](https://codepen.io/gaearon/pen/gWWZgR).

## How to run?

```
git clone repository
cd repository
npm install
REACT_APP_PUB_PUBLISH_KEY="your pubnub publish key" REACT_APP_PUB_SUBSCRIBE_KEY="your pubnub subscribe key" npm start
```


